function Evaluation = EvaluateParams

Evaluation = zeros(100,100,3);

I = imread('lena.jpg');
I = double(I)/255;

size_orig = whos('I');

for k = 10:50
    
   for d =  10:50
       
       tic;
       I_comp = Compress(I,k,d);
       I_rec = Decompress(I_comp);
       
       Evaluation(k,d,1) = toc;
       
       Evaluation(k,d,2) = mean(mean(mean( ((I - I_rec) ).^2)));
       
       size_comp = whos('I_comp');
       Evaluation(k,d,3) = size_comp.bytes / size_orig.bytes;
       
       disp([k d]);
   end
    
end


end

