function I_rec = DecompressDimension( I_comp )


lastCol = size(I_comp);
lastCol = lastCol(2);

width = I_comp(1,lastCol);
length = I_comp(2,lastCol);
d = I_comp(3,lastCol);
xi = width*length/d^2;
paddedX = I_comp(4,lastCol);
paddedY = I_comp(5,lastCol);

Z = I_comp(:,1:xi);
UkT = I_comp(:,xi+1:xi+d^2);

Uk = UkT';

Tau = Uk * Z;

I_rec = zeros(width,length);

x = 1;
y = 1;

for i = 1 : width*length/d^2
    
    if (y > length/d)
        x = x+1;
        y = 1;
    end
    
    M = zeros(d,d);
    
    for j = 1:d
        
        M(:,j) = Tau((j-1)*d+1:j*d,i);
        
    end
    
    I_rec((x-1)*d+1:x*d, (y-1)*d+1:y*d) = M;
    
    y = y+1;
    
end

if (paddedX > 0)
    I_rec(width-paddedX+1:width,:) = [];
end

if (paddedY > 0)
    I_rec(:,length-paddedY+1:length) = [];
end



end

