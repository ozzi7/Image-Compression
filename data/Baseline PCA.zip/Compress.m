function I_comp = Compress(I)

k = 20; % size of new basis k = 30
d = 20; % size of patch d = 32

if (ndims(I) == 2)
    
   I_comp = CompressDimension(I, k, d);
    
else
    
    redCompr = CompressDimension(I(:,:,1), k, d);
    greenCompr = CompressDimension(I(:,:,2), k, d);
    blueCompr = CompressDimension(I(:,:,3), k, d);
    
    I_comp(:,:,1) = redCompr;
    I_comp(:,:,2) = greenCompr;
    I_comp(:,:,3) = blueCompr;
end

end

% for i = 1024:-1:1
%    
%     p(i) = lamda(i,i);
%     
% end
%
% plot(p);
