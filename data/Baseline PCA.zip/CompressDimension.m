function I_comp = CompressDimension( I, k, d )

newI = pad(I,d);

% imshow(I);
% figure;
% imshow(newI);

s = size(newI);
width = s(1);
length = s(2);

X = extract (newI, d);

[mu, lamda, U] = PCAanalyse(X);

Uk = U(:,size(U,2)-k+1:size(U,2));

I_comp = [Uk' * X, Uk'];

settingsVec = zeros(k,1);

sizeOrig = size(I);
sizeNew = size(newI);

settingsVec(1:5,1) = [width; length; d; sizeNew(1)-sizeOrig(1); sizeNew(2)-sizeOrig(2)];

I_comp = [ I_comp, settingsVec];


end

