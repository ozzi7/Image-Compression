function I_rec = Decompress(I_comp)

% Your decompression code goes here!

% I_rec = I_comp.I; % this is just a stump to make the evaluation script run, replace it with your code!

if (ndims(I_comp) == 2)
    
    I_rec = DecompressDimension(I_comp);
    
else
    
    redDecomp = DecompressDimension(I_comp(:,:,1));
    greenDecomp = DecompressDimension(I_comp(:,:,2));
    blueDecomp = DecompressDimension(I_comp(:,:,3));
    
    I_rec(:,:,1) = redDecomp;
    I_rec(:,:,2) = greenDecomp;
    I_rec(:,:,3) = blueDecomp;
    
end


end