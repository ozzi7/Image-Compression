function [ mu, lamda, U ] = PCAanalyse( X )

sigma = cov(X');

[U, lamda] = eig(sigma);

mu = 333; % not needed ???


end

